package it.epicode.be.godfather.model;

public class PizzaHawaiian extends PizzaBase {

	public PizzaHawaiian() {
		super("Pizza Hawaiian (tomato, cheese, ham, pineapple)", 6.49, 1024d);
	}

}

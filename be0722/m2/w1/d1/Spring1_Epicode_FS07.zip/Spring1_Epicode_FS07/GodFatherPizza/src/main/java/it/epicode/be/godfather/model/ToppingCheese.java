/**
 * 
 */
package it.epicode.be.godfather.model;

/**
 * @author gabri
 *
 */
public class ToppingCheese extends PizzaTopping {

	public ToppingCheese(Pizza pizza) {
		super(pizza,"Cheese", 0.69, 92d);
	}

}

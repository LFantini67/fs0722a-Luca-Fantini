package it.epicode.be.godfather;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GodFatherPizzaApplicationTests {

	@Test
	void contextLoads() {
	}

}

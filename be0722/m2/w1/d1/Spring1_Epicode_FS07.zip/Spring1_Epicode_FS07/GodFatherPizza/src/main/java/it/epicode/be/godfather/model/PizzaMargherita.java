package it.epicode.be.godfather.model;

public class PizzaMargherita extends PizzaBase {

	public PizzaMargherita() {
		super("Pizza Margherita (tomato, cheese)", 4.99, 1104d);
	}

}

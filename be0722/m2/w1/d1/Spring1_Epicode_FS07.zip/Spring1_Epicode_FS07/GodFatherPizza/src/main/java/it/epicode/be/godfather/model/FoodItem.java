package it.epicode.be.godfather.model;

public interface FoodItem extends MenuItem {
	
	public Double getCalories();

}
package com.GestionePrenotazioniPostman;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionePrenotazioniPostman1Application {

	public static void main(String[] args) {
		SpringApplication.run(GestionePrenotazioniPostman1Application.class, args);
	}

}

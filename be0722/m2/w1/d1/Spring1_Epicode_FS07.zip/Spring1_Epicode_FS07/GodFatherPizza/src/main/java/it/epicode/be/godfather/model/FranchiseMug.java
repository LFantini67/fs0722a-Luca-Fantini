package it.epicode.be.godfather.model;

public class FranchiseMug extends Franchise {
	
	
	public FranchiseMug() {
		super("Mug",4.99);
	}
}

package com.GestionePrenotazioniPostman.utils;

public enum TipoPostazione {
	PRIVATO, OPENSPACE, SALA_RIUNIONI
}

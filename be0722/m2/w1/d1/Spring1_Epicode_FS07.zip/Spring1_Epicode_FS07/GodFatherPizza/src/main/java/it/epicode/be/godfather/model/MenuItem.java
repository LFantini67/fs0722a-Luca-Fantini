package it.epicode.be.godfather.model;

public interface MenuItem {
	
	public String getName();
	
	public Double getPrice();

	public String getMenuItemLine();

}
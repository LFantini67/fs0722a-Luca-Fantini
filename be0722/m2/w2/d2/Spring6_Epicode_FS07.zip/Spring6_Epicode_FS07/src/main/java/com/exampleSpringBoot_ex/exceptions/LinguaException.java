package com.exampleSpringBoot_ex.exceptions;

public class LinguaException extends RuntimeException{

	public LinguaException(String message) {
		super(message);
		
	}

	
}
